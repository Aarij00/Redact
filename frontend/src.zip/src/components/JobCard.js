import React from 'react';
import { Link } from 'react-router-dom';

const JobCard = ({ job }) => {
    return (
        <div className="job-card">
            <h2>{job.title}</h2>
            <p>{job.description.substring(0, 100)}...</p>
            <Link to={`/getJob/${job._id}`}>View Details</Link>
        </div>
    );
};

export default JobCard;

