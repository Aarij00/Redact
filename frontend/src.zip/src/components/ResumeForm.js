import React, { useState } from 'react';

const ResumeForm = ({ jobId, onSubmit }) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [resume, setResume] = useState(null);

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit({ name, email, resume });
    };

    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                placeholder="Your Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
            />
            <input
                type="email"
                placeholder="Your Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
            />
            <input
                type="file"
                onChange={(e) => setResume(e.target.files[0])}
                required
            />
            <button type="submit">Submit Application</button>
        </form>
    );
};

export default ResumeForm;
