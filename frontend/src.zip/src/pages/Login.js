import React, { useState } from 'react';
import axios from '../services/api';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    
    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            // Send login request to the server
            const response = await axios.post('/auth/login', { email, password });
            
            // Extract the hrId from the response (assuming it's in response.data)
            const hrId = response.data._id;
    
            if (hrId) {
                // Navigate to the dashboard and pass the hrId
                navigate('/dashboard', {state: { hrId }});
            } else {
                throw new Error('HR ID not found in response');
            }
        } catch (err) {
            setError('Invalid email or password');
            console.error('Error during login:', err);
        }
    };
    

    return (
        <div className="login-form">
            <h1>Login</h1>
            {error && <p className="error-text">{error}</p>}
            <form onSubmit={handleLogin}>
                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <button type="submit">Login</button>
            </form>
        </div>
    );
};

export default Login;
