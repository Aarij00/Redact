import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../services/api';
import { useLocation } from 'react-router-dom';

const HrDashboard = () => {
    const [jobPostings, setJobPostings] = useState([]);
    const navigate = useNavigate();
    const location = useLocation();
    const hrId = location.state?.hrId;

    useEffect(() => {
        if (!hrId) {
            console.error('No HR manager ID found');
            return;
        }

        axios.get(`/hr/dashboard/${hrId}`)
            .then(response => setJobPostings(response.data))
            .catch(error => console.error('Error fetching job postings:', error));
    }, [hrId]);

    return (
        <div>
            <h1>Current Postings</h1>
            {jobPostings.length > 0 ? (
                jobPostings.map(job => (
                    <div key={job._id} className="job-card">
                        <h2>{job.title}</h2>
                        <button onClick={() => navigate(`/job-postings/edit/${job._id}`, {state: { hrId }})}>Edit</button>
                        <button onClick={() => navigate(`/job-postings/${job._id}/candidates`)}>View Candidates</button>
                    </div>
                ))
            ) : (
                <p>No job postings available.</p>
            )}
        </div>
    );
};

export default HrDashboard;
