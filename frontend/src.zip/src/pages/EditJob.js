import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import axios from '../services/api';

const EditJob = () => {
    const { jobId } = useParams();
    const navigate = useNavigate();
    const location = useLocation();
    const hrId = location.state?.hrId;
    const [job, setJob] = useState({ title: '', description: '' });

    useEffect(() => {
        axios.get(`/hr/job/edit/${jobId}`)
            .then(response => setJob(response.data))
            .catch(error => console.error('Error fetching job details:', error));
    }, [jobId]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setJob({ ...job, [name]: value });
    };

    const handleSave = () => {
        axios.post(`/hr/job/edit/${jobId}`, job)
            .then(() => navigate('/dashboard', {state: { hrId }}))
            .catch(error => console.error('Error updating job:', error));
    };

    return (
        <div>
            <h1>Edit Job</h1>
            <input
                type="text"
                name="title"
                value={job.title}
                onChange={handleInputChange}
                placeholder="Job Title"
            />
            <textarea
                name="description"
                value={job.description}
                onChange={handleInputChange}
                placeholder="Job Description"
            />
            <button onClick={handleSave}>Save Changes</button>
        </div>
    );
};

export default EditJob;
