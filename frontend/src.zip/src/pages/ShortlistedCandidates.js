import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from '../services/api';

const ShortlistedCandidates = () => {
    const { jobId } = useParams();
    const [candidates, setCandidates] = useState([]);

    useEffect(() => {
        axios.get(`/hr/view-shortlisted/${jobId}`)
            .then(response => setCandidates(response.data))
            .catch(error => console.error('Error fetching shortlisted candidates:', error));
    }, [jobId]);

    const handleSendEmail = () => {
        alert('Email sent to all shortlisted candidates');
        // API call for sending email logic can go here
    };

    return (
        <div>
            <h1>Shortlisted Candidates for Job {jobId}</h1>
            <div>
                {candidates.map(candidate => (
                    <div key={candidate._id}>
                        <p>{candidate.name}</p>
                    </div>
                ))}
            </div>
            <button onClick={handleSendEmail}>Send Email to All</button>
        </div>
    );
};

export default ShortlistedCandidates;
