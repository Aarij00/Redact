import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from '../services/api';

const ViewCandidates = () => {
    const { jobId } = useParams();
    const navigate = useNavigate(); // Added the useNavigate hook
    const [candidates, setCandidates] = useState([]);
    const [selectedCandidate, setSelectedCandidate] = useState(null);

    useEffect(() => {
        axios.get(`/hr/view-candidates/${jobId}`)
            .then(response => setCandidates(response.data))
            .catch(error => console.error('Error fetching candidates:', error));
    }, [jobId]);

    const handleShortlist = (candidateId) => {
        axios.post(`/hr/jobs/${jobId}/shortlist`, { candidateId })
            .then(response => {
                alert(`Candidate ${candidateId} has been shortlisted.`);
                // Optionally, update the local state to reflect the change
                setCandidates(prevCandidates =>
                    prevCandidates.map(candidate =>
                        candidate._id === candidateId
                            ? { ...candidate, status: 'shortlisted' }
                            : candidate
                    )
                );
            })
            .catch(error => {
                console.error('Error shortlisting candidate:', error);
                alert('Failed to shortlist candidate. Please try again.');
            });
    };

    const handleReject = (candidateId) => {
        alert(`Candidate ${candidateId} rejected`);
        // API call for rejection logic can go here
    };

    const handleNavigateToShortlisted = () => {
        navigate(`/job-postings/${jobId}/shortlisted`);
    };

    return (
        <div>
            <h1>Candidates for Job {jobId}</h1>
            <button onClick={handleNavigateToShortlisted}>Shortlisted candidates</button>
            <div>
                {candidates.map(candidate => (
                    <div key={candidate._id} onClick={() => setSelectedCandidate(candidate)}>
                        <p>{candidate.name}</p>
                    </div>
                ))}
            </div>
            {selectedCandidate && (
                <div>
                    <h2>Resume</h2>
                    <iframe src={selectedCandidate.resume} title="Resume" />
                    <button onClick={() => handleShortlist(selectedCandidate._id)}>Shortlist</button>
                    <button onClick={() => handleReject(selectedCandidate._id)}>Reject</button>
                </div>
            )}
        </div>
    );
};

export default ViewCandidates;
