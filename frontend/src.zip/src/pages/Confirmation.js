import React from 'react';
import { Link } from 'react-router-dom';

const Confirmation = () => {
    return (
        <div>
            <h1>Application Submitted</h1>
            <p>Your application has been successfully submitted.</p>
            <Link to="/getJob">Back to Job Postings</Link>
        </div>
    );
};

export default Confirmation;
