import React, { useEffect, useState } from 'react';
import axios from '../services/api';
import JobCard from '../components/JobCard';

const JobPostings = () => {
    const [jobs, setJobs] = useState([]);

    useEffect(() => {
        axios.get('/job/getJob')
            .then(response => setJobs(response.data))
            .catch(error => console.error('Error fetching job postings:', error));
    }, []);

    return (
        <div>
            <h1>Job Postings</h1>
            {jobs.map(job => (
                <JobCard key={job._id} job={job} />
            ))}
        </div>
    );
};

export default JobPostings;
